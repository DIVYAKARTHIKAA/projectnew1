
import React from 'react'
import { Link } from 'react-router-dom';
const AppBar = () => {
  return (
    
    <div className="Mycontainer">
    <div className="card1">
    <Link to="/about"><button class="button4">HOME</button></Link>
    <div className="text1">BODHI PLUS</div>
    </div>
    </div>
  );
}
export default AppBar;